/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package java01.b2;

/**
 *
 * @author felipe.fsilva64
 */
public class Java01B2 {
    public static void frase(){
        System.out.println("imprimindo usando função");
    }
    public static void frase2(){
        System.out.println("continuação da função");
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        frase2();
        frase();
        
    }
    
}
